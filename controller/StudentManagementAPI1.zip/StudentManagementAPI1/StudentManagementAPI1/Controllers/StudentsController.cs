﻿using Microsoft.AspNetCore.Mvc;
using StudentManagementAPI1.Models;

namespace StudentManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StudentsController : ControllerBase
    {
        private static List<Student> students = new List<Student>
        {
            new Student
            {
                Id = 1,
                Name = "John",
                Surname = "Smith",
                Email = "john.smith@example.com",
                Course = "Information Technology",
                Year = 1,
            },

            new Student
            {
                Id = 2,
                Name = "Mary",
                Surname = "Jones",
                Email = "mary.jones@example.com",
                Course = "Computer Science",
                Year = 2,
            },

            new Student
            {
                Id = 3,
                Name = "Peter",
                Surname = "Molefe",
                Email = "peter.molefe@example.com",
                Course = "Information Technology",
                Year = 1,
            },

            new Student
            {
                Id = 4,
                Name = "Sarah",
                Surname = "Mokoena",
                Email = "sarah.mokoena@example.com",
                Course = "Software Development",
                Year = 3,
            },

            new Student
            {
                Id = 5,
                Name = "David",
                Surname = "Naidoo",
                Email = "david.naidoo@example.com",
                Course = "Information Technology",
                Year = 2,
            }
        };

        // GET: api/students
        [HttpGet]
        public IActionResult GetAllStudents()
        {
            return Ok(students);
        }

        // GET: api/students/1
        [HttpGet("{id}")]
        public IActionResult GetStudent(int id)
        {
            var student = students.FirstOrDefault(s => s.Id == id);

            if (student == null)
            {
                return NotFound();
            }

            return Ok(student);
        }

        // POST: api/students
        [HttpPost]
        public IActionResult CreateStudent(Student student)
        {
            int newId = students.Max(s => s.Id) + 1;

            student.Id = newId;

            students.Add(student);

            return CreatedAtAction(
                nameof(GetStudent),
                new { id = student.Id },
                student
            );
        }

        // PUT: api/students/1
        [HttpPut("{id}")]
        public IActionResult UpdateStudent(int id, Student updatedStudent)
        {
            var student = students.FirstOrDefault(s => s.Id == id);

            if (student == null)
            {
                return NotFound();
            }

            student.Name = updatedStudent.Name;
            student.Surname = updatedStudent.Surname;
            student.Email = updatedStudent.Email;
            student.Course = updatedStudent.Course;
            student.Year = updatedStudent.Year;

            return Ok(student);
        }

        // DELETE: api/students/1
        [HttpDelete("{id}")]
        public IActionResult DeleteStudent(int id)
        {
            var student = students.FirstOrDefault(s => s.Id == id);

            if (student == null)
            {
                return NotFound();
            }

            students.Remove(student);

            return NoContent();
        }
    }
}
